CREATE VIEW view_test AS
  SELECT `myfirstdatabase`.`teacher_table`.`teacher_name` AS `teacher_name`
  FROM `myfirstdatabase`.`teacher_table`;
